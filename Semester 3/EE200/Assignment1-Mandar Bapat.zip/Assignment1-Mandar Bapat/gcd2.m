function m = gcd2(x,y,z)
    g = gcd(x,y);
    g = gcd(g,z);
    disp(g)
end