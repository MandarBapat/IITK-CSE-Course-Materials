
function [x,y] = polar2rect(r,theta)
    alpha = cos(theta);
    beta = sin(theta);
    x = r*alpha
    y = r*beta
end