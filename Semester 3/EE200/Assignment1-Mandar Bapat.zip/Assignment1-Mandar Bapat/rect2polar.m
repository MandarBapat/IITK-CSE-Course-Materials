function [r,theta] = rect2polar(x,y)
    r = sqrt(x*x + y*y)
    if((x==0)&(y>0))
        theta = pi/2
    elseif ((x==0) & (y<0))
        theta = -pi/2
    else 
        alpha = atan(abs(y)/abs(x));
        if((x>0)&(y>0))
            theta = alpha
        elseif((x<0)&(y>0))
            theta = pi - alpha
        elseif((x<0)&(y<0))
            theta = -pi + alpha
        else
            theta = -alpha
        end
    end
end